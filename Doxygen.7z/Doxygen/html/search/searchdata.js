var indexSectionsWithContent =
{
  0: "abcdefilmnopsuwx~",
  1: "acdelmosux",
  2: "acdelms",
  3: "abcdeflmpsu~",
  4: "dilmos",
  5: "sw",
  6: "np"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros"
};

