var searchData=
[
  ['backward',['Backward',['../class_dc_motor.html#a861568c6fcbdb280c1a1c3ee25d00bf0',1,'DcMotor']]],
  ['bsetpin',['bSetPin',['../class_ultrasonic_sensor.html#a42761721520184adfe137bbba0636f38',1,'UltrasonicSensor']]]
];
