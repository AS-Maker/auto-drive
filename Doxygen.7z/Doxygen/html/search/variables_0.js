var searchData=
[
  ['description',['description',['../struct_order.html#a6d9bdc739d98088149e23bef2574b729',1,'Order::description()'],['../struct_order_list.html#a5c2b7ac8a7f6f671841f98fc33932adc',1,'OrderList::description()']]]
];
