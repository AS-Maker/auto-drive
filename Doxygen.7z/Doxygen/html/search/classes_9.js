var searchData=
[
  ['xmlreader',['xmlReader',['../classxml_reader.html',1,'']]]
];
