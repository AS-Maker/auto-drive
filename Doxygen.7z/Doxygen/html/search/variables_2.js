var searchData=
[
  ['lagerist',['Lagerist',['../struct_order.html#a2e0bdb085efdfc59ffd49cf37bc518a1',1,'Order']]]
];
