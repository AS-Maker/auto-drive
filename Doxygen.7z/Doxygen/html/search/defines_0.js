var searchData=
[
  ['ncolorred',['nColorRed',['../colorsensor_8h.html#a8015cff794d3bb94d72eceae26391b91',1,'colorsensor.h']]]
];
