var searchData=
[
  ['warehouseclerk',['WarehouseClerk',['../struct_order.html#a59c4cacfbdb7de0aac2e89608ef2238a',1,'Order']]]
];
